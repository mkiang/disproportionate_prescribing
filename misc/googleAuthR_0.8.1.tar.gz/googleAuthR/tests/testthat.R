library(testthat)

test_check("googleAuthR")
